﻿// Core popup-window infrastructure: PopUp() builds/opens a draggable modal, closePopUp/renewPopUp
// manage its lifecycle, PopOut spawns a separate browser window (see wwwroot/js/popout.js), and
// popupList renders a simple list-selection popup.
var MainContainer = "PageContainer";
var jsPopUps = [], ixPopUps = -1, numPopups = 0;
var cancelPopUpFocus = false;

// CMSMailbox adaptation (2026-09-28): this file runs inside ia-viewer.html, itself
// embedded in an <iframe> in CMSMailbox's index.html. PopUp()'s modals are plain divs
// appended into THIS document, so a browser clips/positions them relative to the
// iframe's own small embedded box, not the real browser viewport — reparenting the
// popup's DOM into the parent page isn't viable since everything downstream
// (InteractiveForm.js included) manipulates it via a bare `document.getElementById`
// that always means this iframe's document. Instead, tell the parent page to grow the
// <iframe> ELEMENT ITSELF to full-screen while a popup is open (see index.html's
// message listener) — a no-op, harmlessly, when this file runs directly inside
// CMSNEO itself (not in an iframe).
function mbxNotifyPopupState(isOpen) {
    try {
        if (window.parent !== window) {
            window.parent.postMessage({ mbxPopup: isOpen ? "open" : "closed" }, window.location.origin);
        }
    } catch (ex) { }
}

// ============================================================
// SECTION: popup lifecycle (open/focus/renew/close), PopOut window launch, list-selection popup
// ============================================================
function removeElem(strElem) {
    try {
        var elem = document.getElementById(strElem);
        document.getElementById(elem).parentNode.removeChild(elem);
    } catch (e) {}
}

function closeEmptyPopups() {
    var x = document.getElementsByClassName("PopUp");
    for (var i = 0; i < x.length; i++) {
        var id = x[i].id;
        var ix = id.split("_")[1];
        var xx = document.getElementById("PopUp_" + ix);
        if (xx.innerHTML = "") {
            xx.parentElement.removeChild(xx);
            jsPopUps = jsPopUps.filter(d => d.ix != ix);
        }
    }
}

function PopUpOpt(main, btn, clear) {
    try {
        var opts = main.id.replace("Contents", "Opts");
        console.log("njs 29", main.id, document.getElementById(opts), btn);

        if (clear) opts.innerHTML = "";

        nsection(opts, [
            "label|style=width:10px", btn
        ]);
    } catch (ex) {
        console.log("njs 34", ex);
    }
}

function PopUpFocus(ix) {
    try {
        c_log("popupfocus", ix);
        if (!cancelPopUpFocus) {
            var js = jsPopUps, zindex = 3500;
            if (js.length > 0) {
                sortJS(js, "ZIndex", true);
                zindex = js[0]["ZIndex"] + 10;
            }
            var x = jsPopUps.findIndex(d => d.ix == ix);
            if (x > -1) {
                jsPopUps[x]["ZIndex"] = zindex;
                if (document.getElementById("PopUp_" + ix) != null) {
                    document.getElementById("PopUp_" + ix).style.zIndex = zindex;
                }
            }
        }
    } catch (ex) {

    }

    cancelPopUpFocus = false;
}

function renewPopUp(Title) {
    var xx = jsPopUps.filter(d => d.Title == Title);

    var div = null;
    if (xx.length > 0) { div = xx[0]["Div"] }
    var Data, AppendTitle, Scroll, HeightWidth;

    if (div != null) {//close if already open
        var Data = xx[0]["Data"];
        var AppendTitle = xx[0]["AppendTitle"];
        var Scroll = xx[0]["Scroll"];
        var HeightWidth = xx[0]["HeightWidth"];
        var iMC = xx[0]["MC"];
        var dontMove = xx[0]["dontMove"];

        jsPopUps = jsPopUps.filter(d => d.Div != div);
        var mc = document.getElementById(div);
        console.log(mc);
        mc.parentElement.removeChild(mc);

        console.log(jsPopUps);
        console.log(Title, Data, AppendTitle, Scroll, HeightWidth, iMC, dontMove);
        PopUp(Title, Data, AppendTitle, Scroll, HeightWidth, iMC, dontMove)
    } else {
        return false;
    }
}

function closePopUp(Title, ix) {
    var js, div;
    if (Title != null) { //remove by title
        js = jsPopUps.filter(d => d.Title == Title)[0];
        div = (js != null) ? js["Div"] : null; //get ix by title
    } else {
        div = "PopUp_" + ix;
    }

    if (div != null) {
        try {
            MC = document.getElementById(div);
            MC.parentElement.removeChild(MC);
            jsPopUps = jsPopUps.filter(d => d.Title != Title);
        } catch (e) { }        
    }
    console.log("here");
    var removes = [];
    for (var i = 0; i < jsPopUps.length; i++) {
        var x = jsPopUps[i];
        var d = x.Div;
        if (document.getElementById(d) == null) {removes.push(d)}
    }
    console.log(removes);
    for (var i = 0; i < removes.length; i++) {
        jsPopUps = jsPopUps.filter(d => d.Div != removes[i]);
    }

    var xx = jsPopUps;
    var ix = 0;
    if (xx.length > 0) {
        sortJS(xx, "ix", true);
        ix = xx[0].ix * 1 + 1;
    }
    ixPopUps = ix;
    numPopups = jsPopUps.length;
    mbxNotifyPopupState(jsPopUps.length > 0);
}

// Resize a PopUp from every side and corner (2026-11-18). Replaces CSS resize:both,
// which only offered the bottom-right corner. Handles sit just inside the popup's
// edges (it is overflow:hidden), above the contents, and use pointer events so
// mouse, pen and touch all work. Left/top handles move the popup as they resize it.
function addPopUpResizers(el, minW, minH) {
    if (!el || el.getAttribute("data-resizers") == "1") return;
    el.setAttribute("data-resizers", "1");
    minW = minW || 220; minH = minH || 120;
    var E = 6, C = 14; // edge thickness, corner size (px)
    var defs = [
        ["n", "top:0;left:" + C + "px;right:" + C + "px;height:" + E + "px;cursor:ns-resize"],
        ["s", "bottom:0;left:" + C + "px;right:" + C + "px;height:" + E + "px;cursor:ns-resize"],
        ["w", "left:0;top:" + C + "px;bottom:" + C + "px;width:" + E + "px;cursor:ew-resize"],
        ["e", "right:0;top:" + C + "px;bottom:" + C + "px;width:" + E + "px;cursor:ew-resize"],
        ["nw", "top:0;left:0;width:" + C + "px;height:" + C + "px;cursor:nwse-resize"],
        ["se", "bottom:0;right:0;width:" + C + "px;height:" + C + "px;cursor:nwse-resize"],
        ["ne", "top:0;right:0;width:" + C + "px;height:" + C + "px;cursor:nesw-resize"],
        ["sw", "bottom:0;left:0;width:" + C + "px;height:" + C + "px;cursor:nesw-resize"]
    ];
    defs.forEach(function (d) {
        var h = document.createElement("div");
        h.className = "PopUpResizer PopUpResizer_" + d[0] + " excludePrint";
        h.style.cssText = "position:absolute;z-index:5;touch-action:none;background:transparent;" + d[1];
        h.addEventListener("pointerdown", function (e) { popUpResizeStart(e, d[0], h); });
        h.addEventListener("mousedown", function (e) { e.stopPropagation(); });
        h.addEventListener("click", function (e) { e.stopPropagation(); });
        el.appendChild(h);
    });

    function popUpResizeStart(e, dir, h) {
        if (e.button != null && e.button !== 0) return;
        e.preventDefault(); e.stopPropagation();
        var x0 = e.clientX, y0 = e.clientY;
        var w0 = el.offsetWidth, h0 = el.offsetHeight, l0 = el.offsetLeft, t0 = el.offsetTop;
        try { h.setPointerCapture(e.pointerId); } catch (ex) { }
        var prevSel = document.body.style.userSelect;
        document.body.style.userSelect = "none";
        function move(ev) {
            ev.preventDefault();
            var dx = ev.clientX - x0, dy = ev.clientY - y0;
            if (dir.indexOf("e") >= 0) el.style.width = Math.max(minW, w0 + dx) + "px";
            if (dir.indexOf("s") >= 0) el.style.height = Math.max(minH, h0 + dy) + "px";
            if (dir.indexOf("w") >= 0) {
                var nw = Math.max(minW, w0 - dx);
                el.style.width = nw + "px";
                el.style.left = (l0 + (w0 - nw)) + "px";
            }
            if (dir.indexOf("n") >= 0) {
                var nh = Math.max(minH, h0 - dy), nt = t0 + (h0 - nh);
                if (nt < 0) { nh += nt; nt = 0; } // keep the header on screen
                el.style.height = nh + "px";
                el.style.top = nt + "px";
            }
        }
        function up() {
            h.removeEventListener("pointermove", move);
            h.removeEventListener("pointerup", up);
            h.removeEventListener("pointercancel", up);
            document.body.style.userSelect = prevSel;
            try { window.dispatchEvent(new Event("resize")); } catch (ex) { }
        }
        h.addEventListener("pointermove", move);
        h.addEventListener("pointerup", up);
        h.addEventListener("pointercancel", up);
    }
}

function PopUp(Title, Data, AppendTitle, Scroll, HeightWidth, MC, dontMove) {
    cancelPopUpFocus = true;
    console.log(jsPopUps);

    var removePopUp = jsPopUps.filter(d => d.Title == Title);
    if (removePopUp.length > 0) {
        renewPopUp(Title);
    } else {
        //build new popup
        MC = (MC == null) ? "PageContainer" : MC;
        var js = jsPopUps, ix = 0; zindex = 2500;
        if (js.length > 0) {
            sortJS(js, "ZIndex", true);
            zindex = js[0]["ZIndex"] + 10;

            sortJS(js, "ix", true);
            ix = js[0].ix + 10;
        }

        jsPopUps.push({ Title: Title, ix: ix * 1, Div: ("PopUp_" + ix).replace(/ /g, ""), Data: Data, AppendTitle: AppendTitle, Scroll: Scroll, HeightWidth: HeightWidth, MC: MC, ZIndex: zindex, dontMove: dontMove });
        mbxNotifyPopupState(true);

        HeightWidth = (HeightWidth == null) ? ["500px", "60%"] : HeightWidth;
        var ht = HeightWidth[0].replace("px", "").replace("%", "") * 1;

        ix = ix * 1;
        nsection(MC, [
            "div|id=PopUp_" + ix + "|class=PopUp|style=overflow:hidden; z-index:" + zindex + ";height:" + HeightWidth[0] + ";width:" + HeightWidth[1]
        ]);

        nsection("PopUp_" + ix, [
            "div|id=PopUp_" + ix + "_hdr|onclick=PopUpFocus(" + ix + ")|class=PopUpHdr|style=position: relative; background-color: rgb(31, 41, 67); color: white; height: 50px; border-radius: 5px;|||label|id=PopUp_" + ix + "_hdrTitle|" + Title + "&nbsp;",
            "div|id=PopUp_" + ix + "_Contents|style=border:solid 0px gray; position:relative;padding:10px;width:100%; height: calc(100% - 45px); overflow:auto"
        ]);

        section("PopUp_" + ix + "_hdr", [
            "label|id=PopUp_" + ix + "_hdr_appendTitle|" + ((AppendTitle == null) ? "" : " - " + AppendTitle),
            "div|style=inline-block|id=PopUp_" + ix + "_hdrOpts|class=excludePrint|style=float:right"
        ]);

        dragElement(document.getElementById("PopUp_" + ix));
        addPopUpResizers(document.getElementById("PopUp_" + ix));

        section("PopUp_" + ix + "_hdrOpts", [
            "label|style=padding-right:10px|id=PopUp_" + ix + "_Opts",//this is where you add extra buttons; i.e. submit, delete, etc
            //"label|style=padding-left:10px",
            "label|id=btnPopUpClose_" + ix + "|class=blueButton excludePrint|onclick=closePopUp(null, " + ix + ")|innerHTML=Close"
        ]);

        document.getElementById("PopUp_" + ix + "_Contents").style.overflowY = (Scroll) ? "auto" : "";

        var topLeft = 100;
        topLeft = (!dontMove) ? topLeft + (numPopups * 20) : topLeft;

        document.getElementById("PopUp_" + ix).style.top =
            topLeft + "px";

        document.getElementById("PopUp_" + ix).style.left =
            topLeft + "px";

        //fix broken ix
        var xx = jsPopUps.findIndex(d => d.Title == Title);
        jsPopUps[xx].ix = jsPopUps[xx].Div.split("_")[1] * 1;

        console.log("window open", Title.replace(/ /g, "").replace(/\//g, ""))
        window[Title.replace(/ /g, "").replace(/\//g, "")](document.getElementById("PopUp_" + ix + "_Contents"), Data);
        
    }

}

function PopOut(Title, Data) {
    var MC = (MC == null) ? "PageContainer" : MC;
    var js = jsPopUps, ix = 0; zindex = 2500;
    if (js.length > 0) {
        sortJS(js, "ZIndex", true);
        zindex = js[0]["ZIndex"] + 10;

        sortJS(js, "ix", true);
        ix = js[0].ix + 10;
    }

    jsPopUps.push({ Title: Title, ix: ix * 1, Div: ("PopUp_" + ix).replace(/ /g, ""), Data: Data, AppendTitle: null, Scroll: null, HeightWidth: null, MC: MC, ZIndex: 1000, dontMove: null });

    ix = ix * 1;
    nsection(MC, [
        "div|id=PopUp_" + ix + "|style=height:100%"
    ]);

    nsection("PopUp_" + ix, [
        "input|type=hidden|id=PopUp_" + ix + "_PopOut|value=true",
        "div|id=PopUp_" + ix + "_hdr|onclick=PopUpFocus(" + ix + ")|class=PopUpHdr|||label|id=PopUp_" + ix + "_hdrTitle|" + Title + "&nbsp;",
        "div|id=PopUp_" + ix + "_Contents|style=padding:10px"
    ]);

    document.getElementById("PopUp_" + ix + "_Contents").style.height = "100%";

    section("PopUp_" + ix + "_hdr", [
        "label|id=PopUp_" + ix + "_hdr_appendTitle|",
        "label|id=PopUp_" + ix + "_hdrOpts|class=excludePrint|style=float:right"
    ]);


    section("PopUp_" + ix + "_hdrOpts", [
        "label|style=float:right;padding-right:10px|id=PopUp_" + ix + "_Opts",//this is where you add extra buttons; i.e. submit, delete, etc
        "label|style=padding-left:10px",
        "label|id=btnPopUpClose_" + ix + "|class=blueButton excludePrint|onclick=closePopUp(null, " + ix + ")|innerHTML=Close"
    ]);

    //fix broken ix
    var xx = jsPopUps.findIndex(d => d.Title == Title);
    jsPopUps[xx].ix = jsPopUps[xx].Div.split("_")[1] * 1;

    window[Title.replace(/ /g, "").replace(/\//g, "")](document.getElementById("PopUp_" + ix + "_Contents"), Data);
}


//main popuplist functions
//these would go in their own .js file
function popupList(arr, listName, selectFunc, unselectFunc, MC, TL, HW, Padded) {
    var oArr = [arr, listName, selectFunc, unselectFunc, Padded];
    HW = (HW == null) ? ["400px", "300px"] : HW;
    PopUp("popupListInner", oArr, null, true, HW, MC);

    var js = jsPopUps.filter(d => d.Title == "popupListInner");
    var ix;
    if (js.length > 0) {
        ix = js[0]["ix"];
        var pu = document.getElementById("PopUp_" + ix);
        if (TL != null) {
            pu.style.top = TL[0];
            pu.style.left = TL[1];
        }
    }
}
function popupListInner(main, oArr) {
    var arr = oArr[0].split("="), listName = oArr[1], selectFunc = oArr[2], unselectFunc = oArr[3], Padded = oArr[4];

    var hdr = document.getElementById(main.id.replace("Contents", "hdrTitle"));
    hdr.innerHTML = listName;

    for (var i = 0; i < arr.length; i++) {
        var splitArr = arr[i].split("^");
        var displayItem = arr[i];
        var unavailable = (splitArr.length > 2) ? splitArr[2] : "";
        displayItem = (splitArr.length > 1) ? splitArr[1] : displayItem;

        if (unavailable != "") {
            xsection(main, ["li|class=sm pad" + ((Padded) ? "" : "Left") + "10|name=popupListItems|" + displayItem + "<br>[" + unavailable + "]"]);
        } else {
            xsection(main, ["li|class=alink pad" + ((Padded) ? "" : "Left") + "10|name=popupListItems|onclick=popupListInnerFunc(" + i + ",'" + selectFunc + "','" + unselectFunc + "','" + arr[i] + "')|" + displayItem]);
        }
        
    }
}
function popupListInnerFunc(ix, selectFunc, unselectFunc, item) {
    unselectFunc = (unselectFunc == "null") ? null : unselectFunc;
    if (unselectFunc == null) {
        window[selectFunc](item);
    } else {
        var fld = document.getElementsByName("popupListItems")[ix];
        if (fld.style.textDecoration == "line-through") {
            fld.style.textDecoration = "";
            window[unselectFunc](item);
        } else {
            fld.style.textDecoration = "line-through";
            window[selectFunc](item);
        }
    }
}